These terraform configuration files can be used as a starting template for AWS foundation build.

Fill in the variable values in terraform.tfvars file and update the configuration files per requirements.

Refer below URL for more details on terraform for AWS
https://www.terraform.io/docs/providers/aws/